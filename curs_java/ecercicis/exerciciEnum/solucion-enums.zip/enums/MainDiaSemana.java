package com.ejers2.enums;

import java.util.Scanner;

public class MainDiaSemana {
    public static void main(String[] args) {
        try(Scanner sc = new Scanner(System.in)) {
            System.out.println("Indique un día de la semana: ");
            String dia = sc.nextLine();

            try {
                DiaSemana dow = DiaSemana.valueOf(dia.toUpperCase());
                //DiaSemana dow = DiaSemana.SABADO;
                System.out.println("El día indicado es el -> "+dow);
            } catch(IllegalArgumentException iae){
                System.out.println("ERROR: El día indicado no es correcto!!");
            }
            
        }
    }
}

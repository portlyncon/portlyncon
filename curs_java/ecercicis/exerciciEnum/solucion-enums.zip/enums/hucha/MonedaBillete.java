package com.ejers2.enums.hucha;

public interface MonedaBillete {
    double getValor();
    default double getImporteCalculado(int nElementos){
        return nElementos * this.getValor();
    }
}

package com.ejers2.enums.hucha;

public enum Billete implements MonedaBillete {
    QUINIENTOS_EUROS(500), DOSCIENTOS_EUROS(200), CIEN_EUROS(100),
    CINCUENTA_EUROS(50), VEINTE_EUROS(20), DIEZ_EUROS(10), CINCO_EUROS(5);

    private final double valor;
    Billete(double valor){
        this.valor = valor;
    }

    @Override
    public double getValor() {
        return this.valor;
    }
    
}

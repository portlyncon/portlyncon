package com.ejers2.enums.hucha;

public enum Moneda implements MonedaBillete {
    DOS_EUROS(2), UN_EURO(1), 
    CINCUENTA_CENTIMOS(0.5), VEINTE_CENTIMOS(0.2), DIEZ_CENTIMOS(0.1),
    CINCO_CENTIMOS(0.05), DOS_CENTIMOS(0.01), UN_CENTIMO(0.01);

    private final double valor;
    Moneda(double valor){
        this.valor = valor;
    }

    public double getValor() {
        return this.valor;
    }
}

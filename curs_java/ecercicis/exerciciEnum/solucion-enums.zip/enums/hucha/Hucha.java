package com.ejers2.enums.hucha;

import java.util.HashMap;
import java.util.Map;

public class Hucha {
    private double importeAhorrado = 0;
    private Map<MonedaBillete, Integer> lstMonedaBilleta = new HashMap<>();

    public void add(int n, MonedaBillete tipo) {
        //this.importeAhorrado += n*tipo.getValor();
        this.importeAhorrado += tipo.getImporteCalculado(n);

        //De esta forma en lugar de calcular el valor en el momento de añadir, 
        // lo que hacemos es almacenar la cantidad de monedas/billetes
        // que tenemos de cada tipo
        Integer totalDeEsteTipo = n;
        if(this.lstMonedaBilleta.containsKey(tipo)){
            totalDeEsteTipo+= this.lstMonedaBilleta.get(tipo);
        }
        this.lstMonedaBilleta.put(tipo, totalDeEsteTipo);
    }

    public double total() {
        //return this.importeAhorrado;

        //Usan la segunda estratégia, el importe total habría que calcularlo
        double importeAhorrado = 0;
        for(MonedaBillete tipo: this.lstMonedaBilleta.keySet()){
            importeAhorrado+= tipo.getImporteCalculado(this.lstMonedaBilleta.get(tipo));
        }
        return importeAhorrado;
    }

    public void romper() {
        this.importeAhorrado = 0;

        //Usando la segunda opción
        this.lstMonedaBilleta.clear();
    }

    public String toString(){
        if(this.importeAhorrado>0) {
            return "Tienes "+this.importeAhorrado+"€ en ahorrados";
        } else {
            return "Ohhhh, parece que no tienes nada ahorrado";
        }
    }

    public static void main(String[] args) {
        Hucha cerdito = new Hucha();
        cerdito.add(4, Moneda.CINCUENTA_CENTIMOS);
        cerdito.add(2, Billete.CINCO_EUROS);
        System.out.println(cerdito.total()); // 12
        System.out.println(cerdito); // Tienes 12€ en ahorrados
        cerdito.romper();
        System.out.println(cerdito); // Ohhhh, parece que no tienes nada ahorrado
    }
}

package com.ejers2.enums;

public class Semana {
    private DiaSemana diaActual;

    public Semana(DiaSemana diaActual) {
        this.diaActual = diaActual;
    }

    public void suma(int n){
        int newVal = (this.diaActual.ordinal() + n) % DiaSemana.values().length;
        if(newVal<0) {
            newVal = DiaSemana.values().length + newVal;
        }
        this.diaActual = DiaSemana.values()[newVal];
    }

    public void resta(int n){
        // int newVal = (this.diaActual.ordinal() - n) % DiaSemana.values().length;
        // if(newVal<0) {
        //     newVal = DiaSemana.values().length + newVal;
        // }
        // this.diaActual = DiaSemana.values()[newVal];
        this.suma(-n);
    }
    
    public String toString() {
        return "El día actual es -> "+this.diaActual.toString();
    }

    public static void main(String[] args) {
        Semana s = new Semana(DiaSemana.LUNES);
        System.out.println(s);
        s.suma(9);
        System.out.println(s);
        s.resta(1);
        System.out.println(s);
        s.resta(10);
        System.out.println(s);
    }
}
